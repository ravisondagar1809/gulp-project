const { src, dest, watch, series } = require('gulp');
const sass = require('gulp-sass');
const plumber = require('gulp-plumber');
const concat = require('gulp-concat');
const postcss = require('gulp-postcss');
const cssnano = require('cssnano');
const terser = require('gulp-terser');
const browsersync = require('browser-sync').create();

// Sass Task
function scssTask() {
  return src('parts/scss/style.scss')
    .pipe(sass())
    .pipe(postcss([cssnano()]))
    .pipe(dest('assets/css'));
}

// JavaScript Task
function jsTask() {
  return src([
    'bower_components/jquery/dist/jquery.js',
    'bower_components/bootstrap/dist/js/bootstrap.js',
    'bower_components/bootstrap/js/dist/collapse.js',
    'bower_components/slick-carousel/slick/slick.min.js',
    'bower_components/sticky-kit/jquery.sticky-kit.min.js',
    'bower_components/jquery-nice-select/js/jquery.nice-select.min.js',
    'bower_components/in-view/dist/in-view.min.js',
    'bower_components/aos/dist/aos.js',
    'parts/js/app.js',
  ])
    .pipe(plumber({
      errorHandler: function (error) {
        console.log(error.message);
        this.emit('end');
      }
    }))
    .pipe(concat('script.js'))
    .pipe(terser())
    .pipe(dest('assets/js'));
}

// Browsersync Tasks
function browsersyncServe(cb) {
  browsersync.init({
    server: {
      baseDir: '.'
    }
  });
  cb();
}

function browsersyncReload(cb) {
  browsersync.reload();
  cb();
}

// Watch Task
function watchTask() {
  watch('*.html', browsersyncReload);
  watch(['parts/scss/**/*.scss', 'parts/js/**/*.js'], series(scssTask, jsTask, browsersyncReload));
}

// Default Gulp task
exports.default = series(
  scssTask,
  jsTask,
  browsersyncServe,
  watchTask
);