AOS.init();

$('.slider-for').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false
});

$('.testimonial-content').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  prevArrow: $(".slider--prev"),
  nextArrow: $(".slider--next"),
  dots: false,
  arrows: true,
  focusOnSelect: true,
});

$('.custom-slider-menu').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  dots: false,
  responsive: [
    {
      breakpoint: 1910,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,

      }
    }
  ]
});

$('.footer-gallary').slick({
  slidesToShow: 5,
  slidesToScroll: 1,
  dots: false,
  arrows: false,
});

$('.custom-slider-menu-two').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  dots: false,
  prevArrow: $(".slider--prev"),
  nextArrow: $(".slider--next"),
});


$('.testimonial-content-two').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  prevArrow: $(".slider-two--prev"),
  nextArrow: $(".slider-two--next"),
  dots: false,
  arrows: true,
  focusOnSelect: true,
});

$('.slidere-of-modal').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: false,
  prevArrow: $(".slider--test--prev"),
  nextArrow: $(".slider--test--next"),
});

$('.gallary-slider-scroll').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: false,
  prevArrow: $(".prev-section"),
  nextArrow: $(".next-section"),
});

